-- Adding column mime type to support audio recordingsALTER TABLE attachments ADD COLUMN mime_type TEXT DEFAULT null;
